package com.example.segundointento

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Inmuebles : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inmuebles)

        val tacuasín2= findViewById<Button>(R.id.panda)
        tacuasín2.setOnClickListener { finish()}

        val aguila2=findViewById<Button>(R.id.aguila)
        aguila2.setOnClickListener {
            val aguila3=Intent(this, iusi::class.java)
            startActivity(aguila3)

        val tiburon2=findViewById<Button>(R.id.tiburon)
            tiburon2.setOnClickListener {
                val tiburon3=Intent(this, iva::class.java)
                startActivity(tiburon3)
            }
        }
    }
}

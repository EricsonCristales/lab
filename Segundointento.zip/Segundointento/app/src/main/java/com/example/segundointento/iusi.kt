package com.example.segundointento

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class iusi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_iusi)

        val ballena2=findViewById<Button>(R.id.ballena)
        ballena2.setOnClickListener { finish() }


    }
}
package com.example.segundointento

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class calculatusueldo : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculatusueldo)

        val sueldoEditText: EditText = findViewById(R.id.sueldoEditText)
        val horasExtrasEditText: EditText = findViewById(R.id.horasExtrasEditText)
        val calcularButton: Button = findViewById(R.id.calcularButton)
        val resultadoTextView: TextView = findViewById(R.id.resultadoTextView)


        calcularButton.setOnClickListener {
            val sueldo = sueldoEditText.text.toString().toDoubleOrNull() ?: 0.0
            val horasExtras = horasExtrasEditText.text.toString().toDoubleOrNull() ?: 0.0
            val iggs = sueldo * 0.048
            val irtra = sueldo * 0.01
            val valorHorasExtras = horasExtras * 150.0
            val sueldoTotal = sueldo - iggs - irtra + valorHorasExtras

            val resultadoTexto = "IGGS: Q%.2f\nIRTRA: Q%.2f\nValor Horas Extras: Q%.2f\nSueldo Total: Q%.2f".format(iggs, irtra, valorHorasExtras, sueldoTotal)
            resultadoTextView.text = resultadoTexto

            val jirafa2=findViewById<Button>(R.id.jirafa)
            jirafa2.setOnClickListener { finish() }
        }

    }
}

package com.example.segundointento

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class ubicuenta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ubicuenta)

        val tortuga2=findViewById<Button>(R.id.tortuga)
        tortuga2.setOnClickListener{ finish()}
    }
}
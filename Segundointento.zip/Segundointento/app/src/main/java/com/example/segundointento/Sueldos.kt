package com.example.segundointento

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Sueldos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sueldos)

        val guepardo=findViewById<Button>(R.id.guepardo)
        guepardo.setOnClickListener {
            val guepardo2= Intent(this, calculatusueldo::class.java)
            startActivity(guepardo2)
        }

        val zebra=findViewById<Button>(R.id.zebra)
        zebra.setOnClickListener {
            val zebra2= Intent (this, Liqui::class.java)
            startActivity(zebra2)
        }

        val dodo=findViewById<Button>(R.id.dodo)
        dodo.setOnClickListener {
            val dodo2= Intent (this,contabilidad::class.java)
            startActivity(dodo2)
        }

}
}
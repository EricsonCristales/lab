package com.example.segundointento

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class Liqui : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_liqui)

        val salarioEditText: EditText = findViewById(R.id.salariotext)
        val antiguedadEditText: EditText = findViewById(R.id.antiguedadtext)
        val diasVacacionesEditText: EditText = findViewById(R.id.vacacionestext)
        val calcularButton: Button = findViewById(R.id.ejecutarliqui)
        val resultadoTextView: TextView = findViewById(R.id.resultadotext)
        val otroBoton: Button = findViewById(R.id.backliquidacion) // Nuevo botón

        calcularButton.setOnClickListener {
            val salario = salarioEditText.text.toString().toDoubleOrNull() ?: 0.0
            val antiguedad = antiguedadEditText.text.toString().toIntOrNull() ?: 0
            val diasVacaciones = diasVacacionesEditText.text.toString().toIntOrNull() ?: 0

            val liquidacion = calcularLiquidacion(salario, antiguedad, diasVacaciones)
            resultadoTextView.text = "Liquidación: Q%.2f".format(liquidacion)
        }

        otroBoton.setOnClickListener {
            val intent = Intent(this, Sueldos::class.java)
            startActivity(intent)
        }
    }

    private fun calcularLiquidacion(salario: Double, antiguedad: Int, diasVacaciones: Int): Double {
        val liquidacionAntiguedad = salario * antiguedad * 0.1
        val liquidacionVacaciones = salario * diasVacaciones * 0.2
        val liquidacionTotal = salario + liquidacionAntiguedad + liquidacionVacaciones
        return liquidacionTotal
    }
}

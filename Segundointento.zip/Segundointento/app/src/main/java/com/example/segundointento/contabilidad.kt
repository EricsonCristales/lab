package com.example.segundointento

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.transition.Fade.IN

import android.widget.Button
z
class contabilidad : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contabilidad)

        val camello2=findViewById<Button>(R.id.camello)
        camello2.setOnClickListener { finish() }

        val narval2=findViewById<Button>(R.id.narval)
        narval2.setOnClickListener{
            val ardilla2=Intent(this, Sueldos::class.java)
            startActivity(ardilla2)

        val buho2=findViewById<Button>(R.id.buho)
        buho2.setOnClickListener {
            val buho3=Intent(this, Inmuebles::class.java)
            startActivity(buho3)
        }

        }
    }
}
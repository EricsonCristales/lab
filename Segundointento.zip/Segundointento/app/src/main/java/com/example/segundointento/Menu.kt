package com.example.segundointento

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        val rana2=findViewById<Button>(R.id.rana)
        rana2.setOnClickListener { finish() }

        val regresar1=findViewById<Button>(R.id.venado)
        regresar1.setOnClickListener {
            val perro2= Intent(this, contabilidad::class.java)
            startActivity(perro2)
        }
    }
}